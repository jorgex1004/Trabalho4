#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

const int MAX_ALUNOS = 5;
const int NUM_NOTAS = 3;

struct Aluno {
    string nome;
    float notas[NUM_NOTAS];
    float media;
    string situacao;
};

float calcularMedia(float notas[]) {
    float soma = 0;
    for (int i = 0; i < NUM_NOTAS; i++) {
        soma += notas[i];
    }
    return soma / NUM_NOTAS;
}

int main() {
    Aluno alunos[MAX_ALUNOS];
    int qtdAlunos;
    int indiceMaiorMedia = 0;

    cout << "Digite a quantidade de alunos (até 5): ";
    cin >> qtdAlunos;

    if (qtdAlunos > MAX_ALUNOS || qtdAlunos <= 0) {
        cout << "Quantidade inválida!" << endl;
        return 1;
    }

    for (int i = 0; i < qtdAlunos; i++) {
        cout << "\nDigite o nome do aluno " << i + 1 << ": ";
        cin >> ws;
        getline(cin, alunos[i].nome);

        cout << "Digite as 3 notas de " << alunos[i].nome << ": ";
        for (int j = 0; j < NUM_NOTAS; j++) {
            cin >> alunos[i].notas[j];
        }

        alunos[i].media = calcularMedia(alunos[i].notas);
        alunos[i].situacao = (alunos[i].media >= 7.0) ? "Aprovado" : "Reprovado";

        if (alunos[i].media > alunos[indiceMaiorMedia].media) {
            indiceMaiorMedia = i;
        }
    }

    cout << fixed << setprecision(2);
    cout << "\n--- Tabela de Alunos ---\n";
    cout << left << setw(15) << "Nome" << setw(10) << "Média" << "Situação" << endl;

    for (int i = 0; i < qtdAlunos; i++) {
        cout << left << setw(15) << alunos[i].nome
             << setw(10) << alunos[i].media
             << alunos[i].situacao << endl;
    }

    cout << "\nAluno com a maior média: " << alunos[indiceMaiorMedia].nome
         << " (" << alunos[indiceMaiorMedia].media << ")" << endl;

    return 0;
}